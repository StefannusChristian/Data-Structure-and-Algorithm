How To Run The Program:  python -m keterpencilan
What you Need to Install:
pip install networkx
pip install matplotlib